class Flag:
    def __init__(self):
        self.is_set = False

    def set(self):
        self.is_set = True
