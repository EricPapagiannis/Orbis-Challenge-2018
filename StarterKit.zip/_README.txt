Welcome to the 2018 Orbis Challenge!

In this directory, you'll find 4 folders.
  - Docs: Documentation for the Challenge (open index.html to navigate).
  - IntelliJ: IntelliJ starter kit for Serpentine.
  - PyCharm: PyCharm starter kit for Serpentine.
  - Serpentine: No IDE starter kit for Serpentine.

Depending on what you choose, you can safely ignore the other two folders.

To get started, run Launcher.bat / Launcher.sh (depending on your operating
system) inside the Serpentine folder to see some AIs in action!

More information can be found on the documentations.

Good luck!
