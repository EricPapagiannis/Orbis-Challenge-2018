function playPauseVideo(video) {
	if (video.paused)
        video.play();
    else
        video.pause();
}